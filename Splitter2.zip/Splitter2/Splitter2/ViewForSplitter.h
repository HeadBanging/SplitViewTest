//
//  ViewForSplitter.h
//  Splitter2
//

#import <Cocoa/Cocoa.h>
#import "DebugView.h"

@interface ViewForSplitter : NSView {
    NSPoint lastDragLocation, location;
    BOOL dragging;
}

+ (void)addSplitViewIsVertical:(bool)isVertical inView:(NSView*)view;
- (IBAction)splitHorizontally:(id)sender;

@end
