//
//  ViewForSplitter.m
//  Splitter2
//

#import "ViewForSplitter.h"
#import "AppDelegate.h"

#import "DebugView.h"

@implementation ViewForSplitter

#pragma mark Splitting

+ (void)addSplitViewIsVertical:(bool)isVertical inView:(NSView*)view {
    BOOL newView = YES;
    int newFrameCount = 1;
    
    id viewSplitter = view.superview;
    if ([[viewSplitter class] isSubclassOfClass:[NSSplitView class]] &&
        (((NSSplitView*)viewSplitter).vertical == isVertical)) {
        newView = NO;
    } else {
        if ([[viewSplitter class] isSubclassOfClass:[NSSplitView class]]) {
            newFrameCount = 2;
        }
        viewSplitter = [[NSSplitView alloc] initWithFrame:[view bounds]];
        [viewSplitter setVertical:isVertical];
        ((NSSplitView*)viewSplitter).dividerStyle = NSSplitViewDividerStylePaneSplitter;
    }
    
    int subviewCount = (int)[[viewSplitter subviews]count];
    NSSize superviewSize = view.frame.size;
    NSSize subviewSize;
    subviewSize.width = ((NSSplitView*)viewSplitter).vertical?superviewSize.width:superviewSize.width/subviewCount;
    subviewSize.height = ((NSSplitView*)viewSplitter).vertical?superviewSize.height/subviewCount:superviewSize.height;
    
    for (int i=0;i<newFrameCount;i++){
        ViewForSplitter* contentView = [ViewForSplitter new]; 
        NSRect frameForView = contentView.frame;
        
        frameForView.origin.x=0;
        frameForView.origin.y=0;
        id TestView = [[DebugView alloc] initWithFrame:frameForView];
        [contentView addSubview:TestView];
        [TestView setConstraints];
        
        [TestView testViewWithValue:[[NSApp delegate] getViewCounter]];
        
        NSRect contentFrame = contentView.frame;
        contentFrame.size = subviewSize;
        [contentView setFrame:contentFrame];
        [viewSplitter addSubview:contentView];
        [viewSplitter adjustSubviews];
        
        [contentView setNeedsDisplay:YES];
    }
    
    if (newView) {
        [viewSplitter setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        [view addSubview:viewSplitter]; 
        
        [view setNeedsDisplay:YES];
        
        NSDictionary *views = NSDictionaryOfVariableBindings(viewSplitter); 
        
        [view addConstraints:
         [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[viewSplitter]|"
                                                 options:0
                                                 metrics:nil
                                                   views:views]];
        [view addConstraints:
         [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[viewSplitter]|"
                                                 options:0
                                                 metrics:nil
                                                   views:views]];
    }
}


- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
}

- (NSMenu*)contextualMenu {
    NSMenu *theMenu = [[NSMenu alloc] initWithTitle:@"Contextual Menu"];
    
    NSMenuItem *addHorizontal = [[NSMenuItem alloc] initWithTitle:@"Horizontal Split" action:@selector(splitHorizontally:) keyEquivalent:@""];
    NSMenuItem *addVertical = [[NSMenuItem alloc] initWithTitle:@"Vertical Split" action:@selector(splitVertically:) keyEquivalent:@""];
    NSMenuItem *deleteSplit = [[NSMenuItem alloc] initWithTitle:@"Delete View" action:@selector(deleteView:) keyEquivalent:@""];
    
    [addHorizontal setEnabled:YES];
    [addVertical setEnabled:YES];
    [deleteSplit setEnabled:YES];
    [addHorizontal setTarget:self];
    [addVertical setTarget:self];
    [deleteSplit setTarget:self]; 
    [theMenu addItem:addHorizontal];
    [theMenu addItem:addVertical];
    [theMenu addItem:deleteSplit];

    [theMenu insertItem:[NSMenuItem separatorItem] atIndex:2];

    return theMenu;
}

- (void)rightMouseDown:(NSEvent*)theEvent {
    [[self contextualMenu] popUpMenuPositioningItem:nil atLocation:[NSEvent mouseLocation] inView:nil];
}

- (IBAction)splitHorizontally:(id)sender {
    [ViewForSplitter addSplitViewIsVertical:NO inView:self];
}

- (IBAction)splitVertically:(id)sender {
    [ViewForSplitter addSplitViewIsVertical:YES inView:self];
}

- (IBAction)deleteView:(id)sender {
    if ([[NSApp delegate] currentViewCounter] == 1) {
        return; //mustn't delete the base view!
    }
    
    [self removeFromSuperview];
    [[NSApp delegate] decrementViewCounter];
}

#pragma mark Dragging

- (BOOL)isPointInItem:(NSPoint)testPoint {
    BOOL itemHit=NO;
    
    // test first if we're in the rough bounds
    itemHit = NSPointInRect(testPoint,[self calculatedItemBounds]);
    
    // yes, lets further refine the testing
    if (itemHit) {
        // if this was a non-rectangular shape, you would refine
        // the hit testing here
    }
    
    return itemHit;
}

-(void)mouseDown:(NSEvent *)event {
    NSPoint clickLocation;
    BOOL itemHit=NO;
    
    // convert the mouse-down location into the view coords
    clickLocation = [self convertPoint:[event locationInWindow]
                              fromView:nil];
    
    // did the mouse-down occur in the item?
    itemHit = [self isPointInItem:clickLocation];
    
    // Yes it did, note that we're starting to drag
    if (itemHit) {
        // flag the instance variable that indicates
        // a drag was actually started
        dragging=YES;
        
        // store the starting mouse-down location;
        lastDragLocation=clickLocation;
        
        // set the cursor to the closed hand cursor
        // for the duration of the drag
        [[NSCursor closedHandCursor] push];
    }
}

- (void)resetCursorRects {
    // remove the existing cursor rects
    [self discardCursorRects];
    
    // add the draggable item's bounds as a cursor rect
    
    // clip the draggable item's bounds to the view's visible rect
    NSRect clippedItemBounds = NSIntersectionRect([self visibleRect], [self calculatedItemBounds]);
    
    // if the clipped item bounds isn't empty then the item is at least partially
    // in the visible rect. Register the clipped item bounds
    if (!NSIsEmptyRect(clippedItemBounds)) {
        [self addCursorRect:clippedItemBounds cursor:[NSCursor openHandCursor]];
    }
}

- (NSRect)calculatedItemBounds {
    NSRect calculatedRect;
    
    // calculate the bounds of the draggable item
    // relative to the location
    calculatedRect.origin=location;
    
    // the example assumes that the width and height
    // are fixed values
    calculatedRect.size.width=60.0;
    calculatedRect.size.height=20.0;
    
    return calculatedRect;
}

- (void)offsetLocationByX:(float)x andY:(float)y {
    // tell the display to redraw the old rect
    [self setNeedsDisplayInRect:[self calculatedItemBounds]];
    
    // since the offset can be generated by both mouse moves
    // and moveUp:, moveDown:, etc.. actions, we'll invert
    // the deltaY amount based on if the view is flipped or
    // not.
    int invertDeltaY = [self isFlipped] ? -1: 1;
    
    location.x=location.x+x;
    location.y=location.y+y*invertDeltaY;
    
    // invalidate the new rect location so that it'll
    // be redrawn
    [self setNeedsDisplayInRect:[self calculatedItemBounds]];
    
}

- (void)mouseDragged:(NSEvent *)event {
//    NSPoint mousePoint = [self convertPoint:[event locationInWindow]
//                                   fromView:nil];
    if (dragging) {
    NSPoint newDragLocation=[self convertPoint:[event locationInWindow]
                                      fromView:nil];
    // Could also add the width of the moving rectangle to this check
    // to keep any part of it from going outside the superview
//    mousePoint.x = MAX(0, MIN(mousePoint.x, self.bounds.size.width));
//    mousePoint.y = MAX(0, MIN(mousePoint.y, self.bounds.size.height));

    [self offsetLocationByX:(newDragLocation.x-lastDragLocation.x)
                       andY:(newDragLocation.y-lastDragLocation.y)];
    
    lastDragLocation=newDragLocation;
    // position is a custom ivar that indicates the center of the object;
    // you could also use frame.origin, but it looks nicer if objects are
    // dragged from their centers
 //   myMovingRectangle.position = mousePoint;
    [self setNeedsDisplay:YES];
        [self autoscroll:event];
    }
}

@end
